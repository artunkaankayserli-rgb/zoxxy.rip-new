import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { FaTiktok, FaYoutube, FaTelegramPlane, FaSpotify, FaTwitch, FaDiscord } from "react-icons/fa";
import { IntroOverlay } from "@/components/IntroOverlay";
import { ParticleField } from "@/components/ParticleField";
import { CursorGlow } from "@/components/CursorGlow";
import { Counter } from "@/components/Counter";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ZOXXY — Streamer • Content Creator • Dota 2 Player" },
      { name: "description", content: "Premium creator portfolio of ZOXXY — Dota 2 streamer, content creator, and community builder." },
      { property: "og:title", content: "ZOXXY — Premium Gaming Creator Portfolio" },
      { property: "og:description", content: "Streaming • Content • Dota 2 • Community" },
    ],
  }),
  component: Index,
});

const socials = [
  { name: "TikTok", icon: FaTiktok, href: "https://www.tiktok.com/@zoxxy.rip" },
  { name: "YouTube", icon: FaYoutube, href: "https://youtube.com/@zoxxyrip" },
  { name: "Telegram", icon: FaTelegramPlane, href: "https://t.me/theentlycore" },
  { name: "Spotify", icon: FaSpotify, href: "https://open.spotify.com/user/313n5raeyiph7wu4vjeqb4izeney" },
  { name: "Twitch", icon: FaTwitch, href: "https://twitch.tv/zoxxyprod" },
];

function SocialButton({ s, i }: { s: typeof socials[number]; i: number }) {
  const Icon = s.icon;
  return (
    <motion.a
      href={s.href}
      target="_blank"
      rel="noreferrer"
      aria-label={s.name}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 * i + 0.4, duration: 0.6 }}
      whileHover={{ y: -4, scale: 1.08 }}
      whileTap={{ scale: 0.95 }}
      className="group relative grid h-14 w-14 place-items-center rounded-full glass-card text-gold transition-shadow hover:shadow-[0_0_30px_oklch(0.82_0.15_85/0.6)]"
    >
      <Icon className="h-5 w-5 transition-transform group-hover:scale-110" />
      <span className="pointer-events-none absolute -bottom-7 left-1/2 -translate-x-1/2 whitespace-nowrap text-[10px] font-medium uppercase tracking-widest text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100">
        {s.name}
      </span>
    </motion.a>
  );
}

function Section({ id, eyebrow, title, children }: { id?: string; eyebrow?: string; title: string; children: React.ReactNode }) {
  return (
    <section id={id} className="relative z-10 mx-auto w-full max-w-6xl px-6 py-24 md:py-32">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.8 }}
        className="mb-12 text-center"
      >
        {eyebrow && <p className="mb-3 text-xs font-medium uppercase tracking-[0.4em] text-gold/80">{eyebrow}</p>}
        <h2 className="font-display text-4xl font-bold md:text-6xl text-gradient-gold">{title}</h2>
        <div className="mx-auto mt-4 h-px w-24 bg-gradient-to-r from-transparent via-gold to-transparent" />
      </motion.div>
      {children}
    </section>
  );
}

function Index() {
  return (
    <div className="relative min-h-screen overflow-x-hidden bg-background text-foreground">
      <IntroOverlay />
      <ParticleField />
      <CursorGlow />

      {/* Nav */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 2.6, duration: 0.7 }}
        className="fixed top-0 left-0 right-0 z-40"
      >
        <div className="mx-auto mt-4 flex max-w-6xl items-center justify-between rounded-full glass-card px-6 py-3">
          <span className="font-display text-lg font-black tracking-[0.3em] text-gradient-gold">ZOXXY</span>
          <nav className="hidden gap-8 text-xs font-medium uppercase tracking-widest text-muted-foreground md:flex">
            <a href="#about" className="transition-colors hover:text-gold">About</a>
            <a href="#projects" className="transition-colors hover:text-gold">Projects</a>
            <a href="#stats" className="transition-colors hover:text-gold">Stats</a>
            <a href="#contact" className="transition-colors hover:text-gold">Contact</a>
          </nav>
          <a href="#contact" className="rounded-full border border-gold/40 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest text-gold transition-all hover:bg-gold hover:text-primary-foreground">
            Contact
          </a>
        </div>
      </motion.header>

      {/* Hero */}
      <section className="relative z-10 flex min-h-screen items-center justify-center px-6 pt-24">
        <motion.div
          initial={{ opacity: 0, y: 40, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ delay: 2.8, duration: 1, ease: [0.22, 1, 0.36, 1] }}
          className="relative w-full max-w-3xl"
        >
          {/* Ambient glow */}
          <div className="absolute -inset-10 -z-10 rounded-[3rem] opacity-60 blur-3xl" style={{ background: "var(--gradient-radial-gold)" }} />

          <div className="glass-card rounded-3xl p-10 md:p-14 animate-float-soft">
            <div className="mb-6 flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-70" />
                <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-400" />
              </span>
              <span className="text-xs font-medium uppercase tracking-[0.3em] text-emerald-300/90">Online</span>
            </div>

            <h1 className="font-display text-6xl font-black tracking-[0.15em] md:text-8xl text-gradient-gold leading-none">
              ZOXXY
            </h1>
            <p className="mt-4 text-sm font-medium uppercase tracking-[0.35em] text-gold/80 md:text-base">
              Streamer • Content Creator • Dota 2 Player
            </p>
            <p className="mt-6 max-w-xl text-base leading-relaxed text-muted-foreground md:text-lg">
              Most of my time is spent mastering Dota 2, creating content and building my community.
              I'm focused on growing as a streamer and delivering entertaining content every day.
            </p>

            <div className="mt-10 flex flex-wrap items-center gap-4">
              {socials.map((s, i) => <SocialButton key={s.name} s={s} i={i} />)}
            </div>

            <div className="mt-8 flex items-center gap-3 rounded-2xl border border-gold/15 bg-ink/30 px-4 py-3">
              <FaDiscord className="h-5 w-5 text-gold" />
              <div className="flex-1">
                <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">Discord</p>
                <p className="font-mono text-sm text-foreground">zoxxy.rip</p>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* About */}
      <Section id="about" eyebrow="01 — Profile" title="About Me">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="glass-card mx-auto max-w-3xl rounded-3xl p-10 md:p-14 text-center"
        >
          <p className="text-lg leading-relaxed text-muted-foreground md:text-xl">
            I'm a passionate gamer and content creator focused on Dota 2 and live streaming.
            I enjoy building communities, improving my gameplay and creating memorable moments for viewers.
          </p>
        </motion.div>
      </Section>

      {/* Projects */}
      <Section id="projects" eyebrow="02 — What I Do" title="Projects">
        <div className="grid gap-6 md:grid-cols-2">
          {[
            { t: "Streaming", d: "Daily live streams on Twitch with ranked Dota 2 grinds, viewer games and unfiltered commentary." },
            { t: "Content Creation", d: "Short-form highlights, edits and long-form videos crafted to entertain and educate." },
            { t: "Gaming Highlights", d: "Curated plays, signature moments and clutch moments from competitive gameplay." },
            { t: "Community Building", d: "An active Discord and social presence — a home for fans who love the game and the grind." },
          ].map((p, i) => (
            <motion.div
              key={p.t}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ delay: i * 0.1, duration: 0.7 }}
              whileHover={{ y: -8 }}
              className="group relative overflow-hidden rounded-3xl glass-card p-8 transition-shadow hover:shadow-[var(--shadow-gold-lg)]"
            >
              <div className="absolute inset-0 -z-10 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
                   style={{ background: "radial-gradient(circle at top left, oklch(0.82 0.15 85 / 0.18), transparent 60%)" }} />
              <span className="font-display text-5xl font-black text-gold/20">0{i+1}</span>
              <h3 className="mt-2 font-display text-2xl font-bold text-gradient-gold">{p.t}</h3>
              <p className="mt-3 text-muted-foreground">{p.d}</p>
              <div className="mt-6 h-px w-12 bg-gradient-to-r from-gold to-transparent transition-all duration-500 group-hover:w-full" />
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Collab */}
      <Section eyebrow="03 — Let's Work" title="Open for Collaborations">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative mx-auto max-w-3xl"
        >
          <div className="absolute -inset-6 -z-10 rounded-[3rem] opacity-50 blur-3xl" style={{ background: "var(--gradient-radial-gold)" }} />
          <div className="glass-card rounded-3xl p-10 md:p-14 text-center">
            <p className="text-lg leading-relaxed text-muted-foreground md:text-xl">
              I'm currently open to networking, partnerships and collaboration opportunities.
              If you're interested in working together, feel free to contact me.
            </p>
            <a href="#contact" className="mt-8 inline-flex items-center gap-3 rounded-full px-8 py-3.5 font-semibold uppercase tracking-widest text-primary-foreground transition-all hover:scale-105 hover:shadow-[var(--shadow-gold-lg)]"
               style={{ background: "var(--gradient-gold)" }}>
              Let's Talk
              <span aria-hidden>→</span>
            </a>
          </div>
        </motion.div>
      </Section>

      {/* Stats */}
      <Section id="stats" eyebrow="04 — By The Numbers" title="The Grind">
        <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
          {[
            { v: 480, s: "+", l: "Streams" },
            { v: 12500, s: "+", l: "Hours Played" },
            { v: 320, s: "+", l: "Videos Published" },
            { v: 28000, s: "+", l: "Community Members" },
          ].map((stat, i) => (
            <motion.div
              key={stat.l}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.6 }}
              className="glass-card rounded-2xl p-6 text-center"
            >
              <div className="font-display text-4xl font-black md:text-5xl text-gradient-gold">
                <Counter to={stat.v} suffix={stat.s} />
              </div>
              <p className="mt-2 text-[10px] font-semibold uppercase tracking-[0.25em] text-muted-foreground">{stat.l}</p>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Contact */}
      <Section id="contact" eyebrow="05 — Get In Touch" title="Contact Me">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative mx-auto max-w-4xl"
        >
          <div className="absolute -inset-10 -z-10 rounded-[3rem] opacity-60 blur-3xl" style={{ background: "var(--gradient-radial-gold)" }} />
          <div className="glass-card rounded-3xl p-10 md:p-16 text-center">
            <p className="mx-auto max-w-xl text-lg text-muted-foreground">
              Drop into the DMs on any platform — collabs, partnerships and good conversations always welcome.
            </p>
            <div className="mt-10 flex flex-wrap justify-center gap-5">
              {socials.map((s, i) => <SocialButton key={s.name} s={s} i={i} />)}
            </div>
            <div className="mx-auto mt-8 flex max-w-sm items-center gap-3 rounded-2xl border border-gold/15 bg-ink/30 px-4 py-3">
              <FaDiscord className="h-5 w-5 text-gold" />
              <div className="flex-1 text-left">
                <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">Discord</p>
                <p className="font-mono text-sm text-foreground">zoxxy.rip</p>
              </div>
            </div>
            <a href="https://t.me/theentlycore" target="_blank" rel="noreferrer"
               className="mt-10 inline-flex items-center gap-3 rounded-full px-10 py-4 font-semibold uppercase tracking-widest text-primary-foreground transition-all hover:scale-105 hover:shadow-[var(--shadow-gold-lg)]"
               style={{ background: "var(--gradient-gold)" }}>
              Contact Me
              <span aria-hidden>→</span>
            </a>
          </div>
        </motion.div>
      </Section>

      <footer className="relative z-10 border-t border-gold/10 py-10 text-center">
        <p className="font-display text-sm tracking-[0.3em] text-gold/60">ZOXXY © {new Date().getFullYear()}</p>
      </footer>
    </div>
  );
}
