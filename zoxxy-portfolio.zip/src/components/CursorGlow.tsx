import { useEffect, useState } from "react";

export function CursorGlow() {
  const [p, setP] = useState({ x: -500, y: -500 });
  useEffect(() => {
    const move = (e: MouseEvent) => setP({ x: e.clientX, y: e.clientY });
    window.addEventListener("mousemove", move);
    return () => window.removeEventListener("mousemove", move);
  }, []);
  return (
    <div
      className="pointer-events-none fixed z-[1] h-[500px] w-[500px] rounded-full transition-transform duration-200 ease-out"
      style={{
        left: p.x - 250,
        top: p.y - 250,
        background: "radial-gradient(circle, oklch(0.82 0.15 85 / 0.12), transparent 60%)",
      }}
    />
  );
}
