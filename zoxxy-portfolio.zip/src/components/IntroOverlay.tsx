import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";

export function IntroOverlay() {
  const [show, setShow] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setShow(false), 2800);
    return () => clearTimeout(t);
  }, []);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-ink"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.9, ease: "easeInOut" } }}
        >
          {/* spreading glow */}
          <motion.div
            className="absolute inset-0"
            style={{ background: "var(--gradient-radial-gold)" }}
            initial={{ opacity: 0, scale: 0.3 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.4, ease: "easeOut" }}
          />
          {/* particles */}
          {Array.from({ length: 40 }).map((_, i) => {
            const angle = (i / 40) * Math.PI * 2;
            const dist = 120 + Math.random() * 280;
            return (
              <motion.span
                key={i}
                className="absolute h-1 w-1 rounded-full bg-gold"
                style={{ boxShadow: "0 0 12px var(--gold)" }}
                initial={{ x: 0, y: 0, opacity: 0, scale: 0 }}
                animate={{
                  x: Math.cos(angle) * dist,
                  y: Math.sin(angle) * dist,
                  opacity: [0, 1, 0.6, 0],
                  scale: [0, 1.2, 1, 0.5],
                }}
                transition={{ duration: 2.4, delay: 0.2 + Math.random() * 0.4, ease: "easeOut" }}
              />
            );
          })}
          {/* logo */}
          <motion.div
            className="relative font-display text-6xl md:text-8xl font-black tracking-[0.25em] text-gradient-gold"
            initial={{ opacity: 0, scale: 0.7 }}
            animate={{ opacity: 1, scale: [0.7, 1, 1.05] }}
            transition={{ duration: 2, ease: [0.22, 1, 0.36, 1], times: [0, 0.6, 1] }}
            style={{ filter: "drop-shadow(0 0 30px oklch(0.82 0.15 85 / 0.7))" }}
          >
            ZOXXY
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
